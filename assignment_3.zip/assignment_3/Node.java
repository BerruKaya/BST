package assignment_3;

public class Node {
    int key;
    Node leftNode;
    Node rightNode;

    Node(int k){
        key = k;
        leftNode = null;
        rightNode = null;
    }
}
